import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Create from './pages/Create';
import Results from './pages/Results';
import Student from './pages/Student';

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="sp"/><p style={{color:'#7F77DD',fontSize:14}}>Loading MarkIQ...</p></div>;
  if (!user) return <Navigate to="/login" replace/>;
  return children;
}

function Public({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page-loader"><div className="sp"/></div>;
  if (user) return <Navigate to="/dashboard" replace/>;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing/>}/>
          <Route path="/login" element={<Public><Login/></Public>}/>
          <Route path="/signup" element={<Public><Signup/></Public>}/>
          <Route path="/dashboard" element={<Protected><Dashboard/></Protected>}/>
          <Route path="/create" element={<Protected><Create/></Protected>}/>
          <Route path="/results/:id" element={<Protected><Results/></Protected>}/>
          <Route path="/student" element={<Protected><Student/></Protected>}/>
          <Route path="*" element={<Navigate to="/" replace/>}/>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
