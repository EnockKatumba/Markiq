# MarkIQ — The marking workmate that gives your time back

## Setup Instructions

### 1. Supabase
- Go to supabase.com → your project → SQL Editor
- Run the contents of `supabase_setup.sql`
- Go to Settings → API → copy your Project URL and anon key

### 2. Environment Variables
On Netlify → Site Settings → Environment Variables, add:
```
REACT_APP_SUPABASE_URL=your_supabase_url
REACT_APP_SUPABASE_ANON_KEY=your_supabase_anon_key
ANTHROPIC_KEY=your_anthropic_key
```

### 3. Deploy on Netlify
1. Push this repo to GitHub
2. Go to netlify.com → Add new site → Import from GitHub
3. Select your repo
4. Build command: `npm run build`
5. Publish directory: `build`
6. Add environment variables above
7. Deploy!

### 4. How the AI works
The Netlify function at `netlify/functions/mark.js` proxies all
Anthropic API calls — this avoids CORS errors from the browser.

## Pages
- `/` — Landing page
- `/signup` — Create account
- `/login` — Sign in
- `/dashboard` — Lecturer dashboard
- `/create` — New coursework
- `/results/:id` — Mark students, view results, override, release
- `/student` — Student portal
